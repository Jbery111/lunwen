const config = {
    port: 3000,
    mysql_config: {
      host: 'localhost',   // 数据库地址
      port:'3306',
      user: 'root',    // 数据库用户
      password: 'root',   // 数据库密码
      database: 'tourism'  // 选中数据库名称
    }
    
  };
  module.exports = config;